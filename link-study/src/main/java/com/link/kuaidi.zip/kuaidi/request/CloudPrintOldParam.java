package com.link.kuaidi.request;

import lombok.Data;

/**
 * @Author: api.kuaidi100.com
 * @Date: 2020-07-20 10:43
 */
@Data
public class CloudPrintOldParam {

    private String taskId;
}
