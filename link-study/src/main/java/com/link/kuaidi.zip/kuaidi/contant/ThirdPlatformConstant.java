package com.link.kuaidi.contant;

/**
 * @Author: ligl
 * @Date: 2022-02-17 16:05
 */
public class ThirdPlatformConstant {

    public static final String TAO_BAO = "TAOBAO";
    public static final String JING_DONG = "JINGDONG";
    public static final String DOU_YIN = "TOUTIAO";
    public static final String PIN_DUO_DUO = "PINDUODUO";
}
