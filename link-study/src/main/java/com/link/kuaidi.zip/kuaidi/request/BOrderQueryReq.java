package com.link.kuaidi.request;

import lombok.Data;

/**
 * @Author: api.kuaidi100.com
 * @Date: 2020-09-17 11:17
 */
@Data
public class BOrderQueryReq {

    private String sendAddr;
}
