package com.link.kuaidi.contant;

/**
 * 输出的面单类型
 *
 * @Author: ligl
 * @Date: 2022-04-29 10:34
 */
public enum PrintType {

    HTML,
    IMAGE,
    CLOUD,
    NON,
    ;
}
