package com.link.kuaidi.request;

import lombok.Data;

/**
 * @Author: api.kuaidi100.com
 * @Date: 2020-11-25 16:12
 */
@Data
public class BaseRequest {

    private String url;
}
