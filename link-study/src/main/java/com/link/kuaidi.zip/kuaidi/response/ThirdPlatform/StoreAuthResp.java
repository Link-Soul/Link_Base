package com.link.kuaidi.response.ThirdPlatform;

import lombok.Data;

/**
 * @Author: ligl
 * @Date: 2022-02-17 15:43
 */
@Data
public class StoreAuthResp {
    /**
     * 店铺授权超链接
     */
    private String authorizeUrl;
}
