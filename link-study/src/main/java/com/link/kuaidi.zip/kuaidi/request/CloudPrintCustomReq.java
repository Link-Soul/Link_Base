package com.link.kuaidi.request;

/**
 * @Author: api.kuaidi100.com
 * @Date: 2020-07-20 9:37
 */
public class CloudPrintCustomReq {
}
