package com.link.kuaidi.response.samecity;

import lombok.Data;

/**
 * @Author: api.kuaidi100.com
 * @Date: 2021-03-22 17:32
 */
@Data
public class AuthResp {

    private String url;
}
