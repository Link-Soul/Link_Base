package com.link.kuaidi.contant;

/**
 * @Author: api.kuaidi100.com
 * @Date: 2020-07-15 17:24
 */
public class CompanyConstant {

    public static final String SF = "shunfeng";
    public static final String ZT = "zhongtong";
    public static final String YT = "yuantong";
    public static final String HT = "huitongkuaidi";
    public static final String ST = "shentong";
    public static final String YD = "yunda";
    public static final String EMS = "ems";
    public static final String JD = "jd";
    public static final String ZJS = "zhaijisong";
    public static final String DB = "debangkuaidi";


    public static final String SS = "shansong";
    public static final String JT = "jtexpress";
    public static final String KFW = "kfw";
}
