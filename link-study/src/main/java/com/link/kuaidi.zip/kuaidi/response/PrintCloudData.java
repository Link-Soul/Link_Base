package com.link.kuaidi.response;

import lombok.Data;

/**
 * @Author: api.kuaidi100.com
 * @Date: 2020-07-17 19:49
 */
@Data
public class PrintCloudData {

    private String taskId;

    private String eOrder;

    private String kuaidinum;

    private String kuaidicom;
}
